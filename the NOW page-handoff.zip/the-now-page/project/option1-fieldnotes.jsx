// option1-fieldnotes.jsx
// /now redesigned as a naturalist's field log — manila paper, rubber stamps,
// ruled lines, dates inked in red, handwriting in the margins. Visitor leaves
// a "GUEST OBSERVATION" that gets stamped + filed at the bottom of the log.

const FN_KEY = 'now_fieldnotes_v1';
const FN_PAPER = '#efe5cb';
const FN_RULE  = 'rgba(70, 100, 140, 0.20)';
const FN_INK   = '#1c1a14';
const FN_RED   = '#9b2a1e';
const FN_FADE  = 'rgba(28, 26, 20, 0.55)';

function FNStamp({ children, rotate = -4, color = FN_RED, scale = 1 }) {
  return (
    <span style={{
      display: 'inline-block',
      transform: `rotate(${rotate}deg) scale(${scale})`,
      border: `2px solid ${color}`,
      color, padding: '4px 10px',
      fontFamily: "'Space Mono', monospace",
      fontSize: 11, letterSpacing: '0.22em',
      fontWeight: 700,
      opacity: 0.86,
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.05)',
      whiteSpace: 'nowrap',
    }}>{children}</span>
  );
}

function FNRuled({ children, lines = 10, lineGap = 26, paddingTop = 18 }) {
  // ruled paper — repeating linear gradient
  return (
    <div style={{
      position: 'relative',
      padding: `${paddingTop}px 0 0 0`,
      backgroundImage: `repeating-linear-gradient(to bottom, transparent 0, transparent ${lineGap - 1}px, ${FN_RULE} ${lineGap - 1}px, ${FN_RULE} ${lineGap}px)`,
      backgroundPosition: `0 ${paddingTop}px`,
      minHeight: lines * lineGap,
    }}>{children}</div>
  );
}

function FNObservation({ n, title, items, side }) {
  return (
    <section style={{ position: 'relative', display: 'grid', gridTemplateColumns: '70px 1fr', gap: 18, marginBottom: 28 }}>
      <div style={{ position: 'relative' }}>
        <div style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: 56, fontWeight: 600, color: FN_INK, opacity: 0.85,
          lineHeight: 0.85, letterSpacing: '-0.04em',
        }}>{String(n).padStart(2, '0')}</div>
        <div style={{
          fontFamily: "'Space Mono', monospace", fontSize: 9.5,
          letterSpacing: '0.22em', textTransform: 'uppercase',
          color: FN_FADE, marginTop: 6,
        }}>obs.</div>
        {side && (
          <div style={{
            position: 'absolute', top: 0, left: -56,
            transform: 'rotate(-90deg)', transformOrigin: 'left top',
            fontFamily: "'Space Mono', monospace", fontSize: 9,
            letterSpacing: '0.3em', color: FN_FADE, whiteSpace: 'nowrap',
          }}>{side}</div>
        )}
      </div>
      <div>
        <div style={{
          display: 'flex', alignItems: 'baseline', gap: 14,
          borderBottom: `1px solid ${FN_INK}`, paddingBottom: 6, marginBottom: 12,
        }}>
          <h3 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 22, fontWeight: 600, margin: 0,
            letterSpacing: '-0.015em', color: FN_INK,
            textTransform: 'lowercase',
          }}>{title}</h3>
          <span style={{ flex: 1 }} />
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, letterSpacing: '0.2em', color: FN_FADE, textTransform: 'uppercase' }}>
            n = {items.length}
          </span>
        </div>
        <FNRuled lines={Math.max(items.length, 4)} lineGap={28} paddingTop={4}>
          {items.map((it, i) => (
            <div key={i} style={{
              height: 28, display: 'flex', alignItems: 'center',
              fontFamily: "'Space Mono', monospace", fontSize: 13.5,
              color: FN_INK, gap: 12,
            }}>
              <span style={{ width: 22, color: FN_FADE, fontSize: 11 }}>·{String(i + 1).padStart(2, '0')}</span>
              {it.tag && (
                <span style={{
                  fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
                  border: `1px solid ${FN_INK}`, padding: '1px 6px', color: FN_INK,
                  background: FN_PAPER,
                }}>{it.tag}</span>
              )}
              {it.state && (
                <span style={{
                  fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
                  color: it.state === 'stuck' ? FN_RED : it.state === 'wip' ? FN_INK : FN_FADE,
                  border: `1px solid currentColor`, padding: '1px 6px',
                }}>{it.state}</span>
              )}
              {it.kind && (
                <span style={{
                  fontSize: 9.5, letterSpacing: '0.18em', textTransform: 'uppercase',
                  color: FN_FADE, minWidth: 50,
                }}>{it.kind}</span>
              )}
              <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {it.name && <strong style={{ fontWeight: 500 }}>{it.name}</strong>}
                {it.name && it.detail && <span style={{ color: FN_FADE }}> — {it.detail}</span>}
                {it.val}
              </span>
              {it.meta && (
                <span style={{ fontSize: 10, color: FN_FADE, fontStyle: 'italic', whiteSpace: 'nowrap' }}>{it.meta}</span>
              )}
            </div>
          ))}
        </FNRuled>
      </div>
    </section>
  );
}

function FieldNotesNow() {
  const [draft, setDraft] = React.useState('');
  const [name, setName] = React.useState('');
  const [notes, addNote, clearNotes] = useNotes(FN_KEY);
  const [focusIdx, setFocusIdx] = React.useState(null);

  // seed a couple of demo observations so the log isn't empty on first view
  React.useEffect(() => {
    if (notes.length === 0) {
      const now = Date.now();
      addNote({ name: 'em.',        text: 'rec: bolaño — the savage detectives. you will not sleep.', _ts: now - 3600e3 * 38 });
      addNote({ name: 'anon.',      text: 'have you read borges on tlön?',                                _ts: now - 3600e3 * 5 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    addNote({ name: (name.trim() || 'anon.').slice(0, 24), text: trimmed.slice(0, 180) });
    setDraft(''); setName('');
  };

  return (
    <div style={{
      background: FN_PAPER,
      color: FN_INK,
      fontFamily: "'Space Mono', monospace",
      padding: '40px 56px 56px 56px',
      minHeight: '100%',
      position: 'relative',
      backgroundImage: `
        radial-gradient(rgba(120, 95, 50, 0.06) 1px, transparent 1px),
        radial-gradient(rgba(120, 95, 50, 0.04) 1px, transparent 1px)
      `,
      backgroundSize: '3px 3px, 7px 7px',
      backgroundPosition: '0 0, 1px 2px',
      boxShadow: 'inset 0 0 80px rgba(120, 95, 50, 0.10)',
    }}>
      {/* punched holes down the left edge */}
      <div style={{ position: 'absolute', left: 22, top: 56, bottom: 56, width: 14, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} style={{
            width: 12, height: 12, borderRadius: 12,
            background: 'rgba(0,0,0,0.10)',
            boxShadow: 'inset 1px 1px 2px rgba(0,0,0,0.20)',
          }} />
        ))}
      </div>

      {/* header */}
      <header style={{
        display: 'grid', gridTemplateColumns: '1fr auto auto',
        alignItems: 'flex-end', gap: 24,
        borderBottom: `2px solid ${FN_INK}`,
        paddingBottom: 14, marginBottom: 18,
      }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.32em', textTransform: 'uppercase', color: FN_FADE }}>
            field log · observer: alex gaoth
          </div>
          <h1 style={{
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 66, fontWeight: 600, margin: '6px 0 0 0',
            letterSpacing: '-0.04em', lineHeight: 0.9, color: FN_INK,
            textTransform: 'lowercase',
          }}>the now page<span style={{ color: FN_RED }}>.</span></h1>
          <div style={{ marginTop: 8, fontSize: 11.5, color: FN_FADE }}>
            // a periodic record of what i'm doing, learning, consuming, and where i'm doing it from.
          </div>
        </div>
        <FNStamp rotate={-7}>filed {NOW.date.replace(',', '')}</FNStamp>
        <FNStamp rotate={5} color={FN_INK} scale={0.95}>{NOW.edition}</FNStamp>
      </header>

      {/* metadata bar */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0,
        borderBottom: `1px dashed ${FN_INK}`,
        padding: '8px 0', marginBottom: 28,
        fontSize: 11, letterSpacing: '0.06em',
      }}>
        {[
          ['location', NOW.location],
          ['why',      NOW.why],
          ['tz',       NOW.tz + ' · 24h'],
          ['next sync', 'whenever i push'],
        ].map(([k, v]) => (
          <div key={k}>
            <div style={{ fontSize: 9, letterSpacing: '0.24em', textTransform: 'uppercase', color: FN_FADE, marginBottom: 2 }}>{k}</div>
            <div style={{ color: FN_INK }}>{v}</div>
          </div>
        ))}
      </div>

      {/* observations */}
      <FNObservation n={1} title="building" side="primary activity" items={NOW.building} />
      <FNObservation n={2} title="learning" side="cognitive load"   items={NOW.learning} />
      <FNObservation n={3} title="consuming" side="inputs"          items={NOW.consuming} />
      <FNObservation n={4} title="writing"   side="drafts in flight" items={NOW.writing} />

      {/* this week strip */}
      <section style={{ marginBottom: 36 }}>
        <div style={{
          fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase',
          color: FN_FADE, marginBottom: 6,
        }}>// week-in-review · w20</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', borderTop: `1px solid ${FN_INK}`, borderBottom: `1px solid ${FN_INK}` }}>
          {NOW.thisWeek.map((d, i) => (
            <div key={i} style={{
              padding: '10px 12px',
              borderRight: i < 4 ? `1px solid ${FN_INK}` : 'none',
              display: 'flex', flexDirection: 'column', gap: 6,
              minHeight: 80,
            }}>
              <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: FN_FADE }}>{d.day}</div>
              <div style={{ fontSize: 12.5, lineHeight: 1.3, color: FN_INK }}>{d.val}</div>
              <div style={{ fontSize: 10, color: FN_FADE, marginTop: 'auto' }}>{d.tag}</div>
            </div>
          ))}
        </div>
      </section>

      {/* visitor — guest observation */}
      <section style={{
        border: `2px solid ${FN_INK}`,
        background: 'rgba(255, 250, 235, 0.5)',
        padding: '20px 22px 22px 22px',
        position: 'relative',
        marginBottom: 8,
      }}>
        <div style={{ position: 'absolute', top: -14, left: 22 }}>
          <FNStamp rotate={-3} color={FN_RED}>guest observations</FNStamp>
        </div>
        <p style={{ fontSize: 12, color: FN_FADE, margin: '8px 0 14px 0', maxWidth: '60ch', lineHeight: 1.5 }}>
          leave one. a recommendation, an objection, a thing i should read or notice.
          the form below stamps it with the date and files it into the log. (kept locally on your device — nothing is sent anywhere)
        </p>

        <form onSubmit={submit} style={{ display: 'grid', gridTemplateColumns: '160px 1fr auto', gap: 10, alignItems: 'stretch' }}>
          <input
            type="text" placeholder="signed (or anon.)" maxLength={24}
            value={name} onChange={(e) => setName(e.target.value)}
            style={{
              background: 'transparent', border: `1px solid ${FN_INK}`,
              padding: '10px 12px', fontFamily: "'Space Mono', monospace",
              fontSize: 12.5, color: FN_INK, outline: 'none',
            }}
          />
          <input
            type="text" placeholder="one observation, brief"
            value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={180}
            style={{
              background: 'transparent', border: `1px solid ${FN_INK}`,
              padding: '10px 12px', fontFamily: "'Space Mono', monospace",
              fontSize: 12.5, color: FN_INK, outline: 'none',
            }}
          />
          <button type="submit" style={{
            background: FN_INK, color: FN_PAPER, border: `1px solid ${FN_INK}`,
            fontFamily: "'Space Mono', monospace", fontSize: 11.5,
            letterSpacing: '0.18em', textTransform: 'uppercase',
            padding: '10px 20px', cursor: 'pointer',
          }}>file →</button>
        </form>

        {/* filed entries */}
        <div style={{ marginTop: 22 }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between',
            fontSize: 9.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: FN_FADE,
            paddingBottom: 6, borderBottom: `1px dashed ${FN_INK}`,
          }}>
            <span>// log · {notes.length} entr{notes.length === 1 ? 'y' : 'ies'}</span>
            <button onClick={clearNotes} style={{
              background: 'none', border: 'none', color: FN_FADE,
              fontFamily: "'Space Mono', monospace", fontSize: 9.5,
              letterSpacing: '0.22em', textTransform: 'uppercase', cursor: 'pointer',
            }}>clear ✕</button>
          </div>
          <div style={{ maxHeight: 200, overflowY: 'auto', marginTop: 8 }}>
            {notes.length === 0 ? (
              <div style={{ fontSize: 12, color: FN_FADE, fontStyle: 'italic', padding: '14px 0' }}>
                // no observations on file. leave the first.
              </div>
            ) : notes.map((n, i) => (
              <div
                key={i}
                onMouseEnter={() => setFocusIdx(i)} onMouseLeave={() => setFocusIdx(null)}
                style={{
                  display: 'grid', gridTemplateColumns: '110px 90px 1fr',
                  gap: 14, alignItems: 'baseline',
                  padding: '7px 0', borderBottom: `1px dotted ${FN_INK}`,
                  fontSize: 12.5,
                  background: focusIdx === i ? 'rgba(155, 42, 30, 0.06)' : 'transparent',
                  transition: 'background 0.12s',
                }}
              >
                <span style={{ fontSize: 10, color: FN_RED, letterSpacing: '0.08em' }}>{fmtStamp(n._ts || n.ts)}</span>
                <span style={{ fontSize: 11, color: FN_FADE, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>— {n.name}</span>
                <span style={{ color: FN_INK }}>{n.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* footer */}
      <footer style={{
        display: 'flex', justifyContent: 'space-between',
        marginTop: 24, fontSize: 10, letterSpacing: '0.2em',
        textTransform: 'uppercase', color: FN_FADE,
      }}>
        <span>// inspired by derek sivers' /now movement</span>
        <span>page 01 of 01</span>
      </footer>
    </div>
  );
}

window.FieldNotesNow = FieldNotesNow;
