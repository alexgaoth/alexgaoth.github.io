// now-data.jsx — shared data used by all four /now redesigns
// Lifted from profile.json + the project context (signalor, sdx, jung, etc.)

const NOW = {
  date: 'may 16, 2026',
  edition: 'vol. 003 · no. 41',
  location: 'la jolla, california',
  why: 'home for summer · sdx @ ucsd',
  tz: 'pdt',
  building: [
    { name: 'signalor.app', detail: 'v0.3 · google analytics for brands · in production', tag: 'live' },
    { name: 'sdx @ ucsd', detail: 'design-engineering club · 3 brand pitches this week', tag: 'wip' },
    { name: 'this very site', detail: 'preview rail redesign · the page you are on', tag: 'wip' },
  ],
  learning: [
    { name: 'rust',                detail: 'borrow checker, finally' },
    { name: 'தமிழ் / tamil',       detail: 'reading aloud, slowly' },
    { name: 'writing more clearly', detail: 'fewer words, harder meaning' },
  ],
  consuming: [
    { kind: 'sound', val: 'soldier of heaven — sabaton', meta: 'on repeat' },
    { kind: 'read',  val: 'the undiscovered self — c.g. jung', meta: 'ch. 4 of 7' },
    { kind: 'watch', val: 'xavier: renegade angel', meta: 's2' },
    { kind: 'play',  val: 'none actually', meta: '—' },
  ],
  writing: [
    { state: 'wip',   val: 'a note on metaphor as compression' },
    { state: 'open',  val: 'the politics of attention' },
    { state: 'stuck', val: 'a story about the fall of nineveh' },
  ],
  thisWeek: [
    { day: 'mon', val: 'signalor v0.3.2 shipped',         tag: '+340 −120' },
    { day: 'tue', val: 'sdx pitches · 3 brands',          tag: '4 hrs' },
    { day: 'wed', val: 'jung — finished chapter 4',       tag: 'read' },
    { day: 'thu', val: 'preview rail redesign · this',    tag: 'wip' },
    { day: 'fri', val: 'open',                            tag: '—' },
  ],
};

// ── localStorage helpers for visitor-left notes (each option uses its own key) ──
function useNotes(storageKey) {
  const [notes, setNotes] = React.useState(() => {
    try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); }
    catch (e) { return []; }
  });
  const addNote = React.useCallback((note) => {
    setNotes((prev) => {
      const next = [{ ...note, ts: Date.now() }, ...prev].slice(0, 50);
      try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch (e) {}
      return next;
    });
  }, [storageKey]);
  const clearNotes = React.useCallback(() => {
    setNotes([]);
    try { localStorage.removeItem(storageKey); } catch (e) {}
  }, [storageKey]);
  return [notes, addNote, clearNotes];
}

function fmtStamp(ts) {
  const d = new Date(ts);
  const months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(d.getDate())} ${months[d.getMonth()]} ${String(d.getFullYear()).slice(-2)} · ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

Object.assign(window, { NOW, useNotes, fmtStamp });
