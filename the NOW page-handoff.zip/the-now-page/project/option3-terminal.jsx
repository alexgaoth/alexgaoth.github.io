// option3-terminal.jsx
// /now as a live tmux-style status dashboard. Multiple panes, ticking clock,
// uptime, htop-ish bars. Visitor sends `ping <message>` from the prompt and
// it lands in the system log alongside Alex's recent commits and pings.

const T_KEY  = 'now_terminal_v1';
const T_BG   = '#0d0e0c';
const T_BG2  = '#16171a';
const T_FG   = '#e7e3d4';
const T_DIM  = 'rgba(231, 227, 212, 0.55)';
const T_HAIR = 'rgba(231, 227, 212, 0.12)';
const T_AMB  = '#e3b341';   // amber accent
const T_GRN  = '#7ad08a';   // status ok
const T_RED  = '#e16a5b';   // alert

function TBar({ pct, color = T_GRN, cells = 24 }) {
  const filled = Math.round(pct * cells);
  return (
    <span style={{ color, letterSpacing: '0.08em' }}>
      {'█'.repeat(filled)}
      <span style={{ color: T_HAIR }}>{'░'.repeat(cells - filled)}</span>
    </span>
  );
}

function TPaneTitle({ name, n, total }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '6px 10px',
      borderBottom: `1px solid ${T_HAIR}`,
      background: T_BG2,
    }}>
      <span style={{ fontSize: 10.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: T_AMB }}>
        ▸ {name}
      </span>
      {n != null && (
        <span style={{ fontSize: 10, color: T_DIM, letterSpacing: '0.18em' }}>
          [{n}/{total}]
        </span>
      )}
    </div>
  );
}

function TerminalNow() {
  const [time, setTime] = React.useState(new Date());
  const [draft, setDraft] = React.useState('');
  const [name, setName]   = React.useState('');
  const [pings, addPing, clearPings] = useNotes(T_KEY);
  const logRef = React.useRef(null);

  // Live clock + uptime
  React.useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // seed demo pings
  React.useEffect(() => {
    if (pings.length === 0) {
      const now = Date.now();
      addPing({ name: 'jules@kitchen-table',     text: 'reading the manzikert essay. you should write longer.', _ts: now - 3600e3 * 22 });
      addPing({ name: 'asha@1138.local',         text: 'recommendation: tarkovsky — mirror. let it sit.',        _ts: now - 3600e3 * 6 });
      addPing({ name: 'anon@104.18.x.x',         text: 'rust tip: stop fighting Box<dyn>, just write enums.',    _ts: now - 3600e3 * 1.2 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fmtTime = (d) => {
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };

  const submit = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    addPing({ name: (name.trim() || 'guest@unknown').slice(0, 28), text: trimmed.slice(0, 180) });
    setDraft('');
    requestAnimationFrame(() => {
      if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
    });
  };

  // commit log (static fake history with relative ages for realism)
  const COMMITS = [
    { hash: 'a7f31e2', msg: 'now-page: redesign preview rail',  ago: '14 min',  refs: ['HEAD', 'main'] },
    { hash: '93b0f12', msg: 'signalor: v0.3.2 release',          ago: '2 days',  refs: ['v0.3.2'] },
    { hash: '6c2a8d4', msg: 'sdx-pitch: brand 03 deck slides',   ago: '3 days',  refs: [] },
    { hash: 'd5e91a0', msg: 'thoughts: metaphor as compression', ago: '4 days',  refs: [] },
    { hash: 'f81cc3b', msg: 'signalor: dashboard latency fix',   ago: '6 days',  refs: [] },
  ];

  return (
    <div style={{
      background: T_BG, color: T_FG,
      fontFamily: "'Space Mono', monospace",
      padding: 18, minHeight: '100%',
      backgroundImage: `
        radial-gradient(circle at 20% 0%, rgba(227, 179, 65, 0.04) 0, transparent 50%),
        radial-gradient(circle at 80% 100%, rgba(122, 208, 138, 0.03) 0, transparent 50%)
      `,
      position: 'relative',
    }}>
      {/* faint scanline overlay */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: 'repeating-linear-gradient(to bottom, rgba(255,255,255,0.012) 0 1px, transparent 1px 3px)',
        mixBlendMode: 'overlay',
      }} />

      {/* ── top status bar ───────────────────────────────────── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'auto 1fr auto auto auto auto',
        gap: 18, alignItems: 'center',
        padding: '8px 12px',
        border: `1px solid ${T_HAIR}`,
        background: T_BG2,
        marginBottom: 12, fontSize: 11.5,
      }}>
        <span style={{ color: T_AMB, letterSpacing: '0.16em' }}>
          ◉ alex@now ~ %
        </span>
        <span style={{ color: T_DIM }}>
          building: <span style={{ color: T_FG }}>signalor.app · v0.3</span>
          &nbsp;&nbsp;·&nbsp;&nbsp; at: <span style={{ color: T_FG }}>{NOW.location}</span>
        </span>
        <span style={{ color: T_DIM }}>uptime <span style={{ color: T_FG }}>19y 2m 14d</span></span>
        <span style={{ color: T_DIM }}>load <span style={{ color: T_GRN }}>0.62 0.41 0.28</span></span>
        <span style={{ color: T_DIM }}>{NOW.tz}</span>
        <span style={{ color: T_GRN, letterSpacing: '0.14em' }}>{fmtTime(time)}</span>
      </div>

      {/* ── BANNER ─────────────────────────────────────────── */}
      <div style={{
        border: `1px solid ${T_HAIR}`,
        padding: '20px 22px 18px 22px',
        marginBottom: 12, background: T_BG2,
        display: 'grid', gridTemplateColumns: '1fr auto', gap: 24, alignItems: 'flex-end',
      }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.32em', textTransform: 'uppercase', color: T_DIM, marginBottom: 8 }}>
            $ cat /now &nbsp;<span style={{ color: T_AMB }}>──</span>&nbsp; alex gaoth, current state
          </div>
          <div style={{
            display: 'flex', alignItems: 'baseline', gap: 14, flexWrap: 'wrap',
            fontFamily: "'Space Grotesk', sans-serif",
            fontSize: 76, lineHeight: 0.9,
            letterSpacing: '-0.04em', fontWeight: 500, color: T_FG,
            textTransform: 'lowercase',
          }}>
            <span>now<span style={{ color: T_AMB }}>.</span>live</span>
            <span style={{
              fontFamily: "'Space Mono', monospace", fontSize: 13,
              letterSpacing: '0.22em', color: T_GRN,
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ display: 'inline-block', width: 7, height: 7, borderRadius: 7, background: T_GRN, animation: 'pulseT 1.4s ease-in-out infinite' }} />
              ONLINE · last sync {fmtTime(time)}
            </span>
          </div>
          <div style={{ marginTop: 12, fontSize: 12.5, color: T_DIM, maxWidth: '70ch', lineHeight: 1.55 }}>
            // a live readout of what i'm building, learning, consuming, and where i'm
            doing it from. polled from <span style={{ color: T_AMB }}>profile.json</span> on every push.
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 10, letterSpacing: '0.22em', color: T_DIM, textTransform: 'uppercase' }}>session</div>
          <div style={{ fontSize: 13, color: T_FG }}>{NOW.date}</div>
          <div style={{ fontSize: 11, color: T_DIM, marginTop: 2 }}>{NOW.edition}</div>
        </div>
      </div>

      {/* ── 3-column main grid ───────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr 1fr', gap: 12 }}>

        {/* LEFT — htop processes (building) */}
        <div style={{ border: `1px solid ${T_HAIR}` }}>
          <TPaneTitle name="ps · building" n={NOW.building.length} total={NOW.building.length} />
          <div style={{ padding: '10px 12px', fontSize: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '56px 1fr 70px 60px', gap: 10, padding: '4px 0', borderBottom: `1px solid ${T_HAIR}`, fontSize: 10, letterSpacing: '0.16em', color: T_DIM, textTransform: 'uppercase' }}>
              <span>pid</span><span>process</span><span>cpu%</span><span>state</span>
            </div>
            {NOW.building.map((b, i) => {
              const cpu = [82, 56, 31][i] || 20;
              return (
                <div key={i} style={{ padding: '8px 0', borderBottom: `1px dotted ${T_HAIR}` }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '56px 1fr 70px 60px', gap: 10, alignItems: 'baseline' }}>
                    <span style={{ color: T_DIM }}>{1000 + i * 7}</span>
                    <span style={{ color: T_FG }}>{b.name}</span>
                    <span style={{ color: cpu > 60 ? T_AMB : T_GRN }}>{cpu}%</span>
                    <span style={{ color: T_GRN, fontSize: 10, letterSpacing: '0.18em' }}>{b.tag}</span>
                  </div>
                  <div style={{ fontSize: 10.5, color: T_DIM, marginTop: 4, paddingLeft: 0 }}>↳ {b.detail}</div>
                  <div style={{ marginTop: 5, fontSize: 10 }}>
                    <TBar pct={cpu / 100} cells={32} color={cpu > 60 ? T_AMB : T_GRN} />
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ borderTop: `1px solid ${T_HAIR}`, padding: '8px 12px', display: 'flex', justifyContent: 'space-between', fontSize: 10.5, color: T_DIM }}>
            <span>total cpu <span style={{ color: T_AMB }}>56%</span></span>
            <span>mem 4.1 / 8 gb</span>
            <span>swap none</span>
          </div>
        </div>

        {/* MIDDLE — input streams (learning + consuming + writing) */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ border: `1px solid ${T_HAIR}` }}>
            <TPaneTitle name="streams · consuming" />
            <div style={{ padding: '10px 12px', fontSize: 12 }}>
              {NOW.consuming.map((c, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '60px 1fr auto', gap: 10, padding: '5px 0', borderBottom: i < NOW.consuming.length - 1 ? `1px dotted ${T_HAIR}` : 'none', alignItems: 'baseline' }}>
                  <span style={{ color: T_AMB, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{c.kind}</span>
                  <span style={{ color: T_FG }}>{c.val}</span>
                  <span style={{ color: T_DIM, fontSize: 10.5 }}>{c.meta}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ border: `1px solid ${T_HAIR}` }}>
            <TPaneTitle name="open files · learning" />
            <div style={{ padding: '10px 12px', fontSize: 12 }}>
              {NOW.learning.map((l, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, padding: '5px 0', borderBottom: i < NOW.learning.length - 1 ? `1px dotted ${T_HAIR}` : 'none' }}>
                  <span style={{ color: T_GRN, minWidth: 16 }}>{i + 1}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: T_FG }}>{l.name}</div>
                    <div style={{ color: T_DIM, fontSize: 10.5 }}>{l.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ border: `1px solid ${T_HAIR}` }}>
            <TPaneTitle name="branches · writing" />
            <div style={{ padding: '10px 12px', fontSize: 11.5 }}>
              {NOW.writing.map((w, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '70px 1fr', gap: 8, padding: '4px 0' }}>
                  <span style={{
                    color: w.state === 'stuck' ? T_RED : w.state === 'wip' ? T_AMB : T_DIM,
                    fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase',
                  }}>● {w.state}</span>
                  <span style={{ color: T_FG }}>{w.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT — git log + this week */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ border: `1px solid ${T_HAIR}` }}>
            <TPaneTitle name="git log --oneline" />
            <div style={{ padding: '10px 12px', fontSize: 11.5 }}>
              {COMMITS.map((c, i) => (
                <div key={i} style={{ padding: '4px 0', display: 'grid', gridTemplateColumns: '74px 1fr auto', gap: 8, alignItems: 'baseline' }}>
                  <span style={{ color: T_AMB }}>{c.hash}</span>
                  <span style={{ color: T_FG, fontSize: 11.5 }}>
                    {c.refs.length > 0 && (
                      <span style={{ color: T_GRN, marginRight: 6 }}>
                        ({c.refs.join(', ')})
                      </span>
                    )}
                    {c.msg}
                  </span>
                  <span style={{ color: T_DIM, fontSize: 10 }}>{c.ago} ago</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ border: `1px solid ${T_HAIR}` }}>
            <TPaneTitle name="cron · this week" />
            <div style={{ padding: '10px 12px', fontSize: 11.5 }}>
              {NOW.thisWeek.map((d, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '36px 1fr auto', gap: 8, padding: '4px 0', borderBottom: i < NOW.thisWeek.length - 1 ? `1px dotted ${T_HAIR}` : 'none' }}>
                  <span style={{ color: T_AMB, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{d.day}</span>
                  <span style={{ color: T_FG }}>{d.val}</span>
                  <span style={{ color: T_DIM, fontSize: 10 }}>{d.tag}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── interactive · ping the box ───────────────────── */}
      <div style={{ marginTop: 12, border: `1px solid ${T_HAIR}`, background: T_BG2 }}>
        <TPaneTitle name="netcat · incoming pings" />
        <div style={{ padding: '10px 12px' }}>
          <div style={{ fontSize: 11, color: T_DIM, marginBottom: 10, lineHeight: 1.55, maxWidth: '90ch' }}>
            // open port. send a ping — a rec, a wave, an objection. lands in
            the log next to alex's recent commits. <span style={{ color: T_AMB }}>kept on your machine; nothing leaves.</span>
          </div>

          <form onSubmit={submit} style={{
            display: 'grid', gridTemplateColumns: 'auto 200px 1fr auto',
            gap: 8, alignItems: 'stretch',
            padding: '8px 0',
          }}>
            <span style={{ color: T_GRN, alignSelf: 'center', fontSize: 12.5 }}>$ ping</span>
            <input type="text" placeholder="from (user@host)" maxLength={28} value={name} onChange={(e) => setName(e.target.value)} style={{
              background: T_BG, border: `1px solid ${T_HAIR}`,
              padding: '8px 10px', fontFamily: "'Space Mono', monospace",
              fontSize: 12, color: T_AMB, outline: 'none',
            }} />
            <input type="text" placeholder="payload — one line" maxLength={180} value={draft} onChange={(e) => setDraft(e.target.value)} style={{
              background: T_BG, border: `1px solid ${T_HAIR}`,
              padding: '8px 10px', fontFamily: "'Space Mono', monospace",
              fontSize: 12, color: T_FG, outline: 'none',
            }} />
            <button type="submit" style={{
              background: T_AMB, color: T_BG, border: `1px solid ${T_AMB}`,
              fontFamily: "'Space Mono', monospace", fontSize: 11,
              letterSpacing: '0.2em', textTransform: 'uppercase',
              padding: '8px 18px', cursor: 'pointer', fontWeight: 700,
            }}>↵ send</button>
          </form>

          <div ref={logRef} style={{ maxHeight: 180, overflowY: 'auto', marginTop: 6, paddingTop: 6, borderTop: `1px solid ${T_HAIR}`, fontSize: 12 }}>
            {pings.length === 0 ? (
              <div style={{ fontStyle: 'italic', color: T_DIM, padding: '8px 0' }}>(log empty — quiet on the wire)</div>
            ) : pings.map((p, i) => (
              <div key={i} style={{ padding: '4px 0', display: 'grid', gridTemplateColumns: '120px 200px 1fr', gap: 10, borderBottom: i < pings.length - 1 ? `1px dotted ${T_HAIR}` : 'none', alignItems: 'baseline' }}>
                <span style={{ color: T_GRN, fontSize: 10.5 }}>[{fmtStamp(p._ts || p.ts)}]</span>
                <span style={{ color: T_AMB, fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
                <span style={{ color: T_FG }}>&lt; {p.text}</span>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 8, display: 'flex', justifyContent: 'space-between', fontSize: 10, letterSpacing: '0.16em', color: T_DIM, textTransform: 'uppercase' }}>
            <span>{pings.length} packet{pings.length === 1 ? '' : 's'} received</span>
            <button onClick={clearPings} style={{
              background: 'none', border: 'none', color: T_DIM, cursor: 'pointer',
              fontFamily: "'Space Mono', monospace", fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase',
            }}>$ rm /var/log/pings ✕</button>
          </div>
        </div>
      </div>

      {/* footer status */}
      <div style={{ marginTop: 12, fontSize: 10.5, color: T_DIM, display: 'flex', justifyContent: 'space-between', letterSpacing: '0.16em', textTransform: 'uppercase' }}>
        <span>$ tail -f /alex/now</span>
        <span>derek sivers — /now movement · since 2015</span>
        <span style={{ color: T_GRN }}>● connection healthy</span>
      </div>

      <style>{`@keyframes pulseT { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.3; transform: scale(0.8); } }`}</style>
    </div>
  );
}

window.TerminalNow = TerminalNow;
