// option2-broadsheet.jsx
// /now as a broadsheet front page. Serif masthead, justified body, multi-column.
// Visitor places a one-line classified ad in the back-of-paper section.

const BS_KEY    = 'now_broadsheet_v1';
const BS_PAPER  = '#f4f1e8';
const BS_INK    = '#16140f';
const BS_FADE   = '#6b6657';
const BS_RULE   = 'rgba(22, 20, 15, 0.18)';
const BS_HAIR   = 'rgba(22, 20, 15, 0.10)';

const CLASSIFIED_CATEGORIES = ['wave', 'rec', 'have', 'want', 'objection'];

function BSRule({ thick = 1, color = BS_RULE, margin = '12px 0' }) {
  return <div style={{ height: thick, background: color, margin }} />;
}

function BSColumnRule() {
  return <div style={{ width: 1, background: BS_RULE, alignSelf: 'stretch' }} />;
}

function BroadsheetNow() {
  const [draft, setDraft] = React.useState('');
  const [name, setName]   = React.useState('');
  const [category, setCategory] = React.useState('rec');
  const [notes, addNote, clearNotes] = useNotes(BS_KEY);

  React.useEffect(() => {
    if (notes.length === 0) {
      const now = Date.now();
      addNote({ name: 'm.f.',  category: 'rec', text: 'try eliot’s four quartets — east coker first. won’t leave you alone.', _ts: now - 3600e3 * 19 });
      addNote({ name: 'anon.', category: 'wave', text: 'reading this from bangalore. you write well.', _ts: now - 3600e3 * 4 });
      addNote({ name: 'k.',    category: 'objection', text: 'jung is a vibe, not an argument. fight me.', _ts: now - 3600e3 * 1 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    addNote({ name: (name.trim() || 'anon.').slice(0, 20), category, text: trimmed.slice(0, 110) });
    setDraft(''); setName('');
  };

  return (
    <div style={{
      background: BS_PAPER, color: BS_INK,
      fontFamily: "'Space Mono', monospace",
      padding: '34px 50px 44px 50px',
      minHeight: '100%',
      backgroundImage: `
        radial-gradient(rgba(40, 30, 20, 0.025) 1px, transparent 1px),
        radial-gradient(rgba(40, 30, 20, 0.020) 1px, transparent 1px)
      `,
      backgroundSize: '4px 4px, 9px 9px',
    }}>
      {/* folio bar */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase',
        color: BS_FADE, paddingBottom: 6,
        borderBottom: `1px solid ${BS_RULE}`,
      }}>
        <span>{NOW.edition}</span>
        <span>alexgaoth.com / now</span>
        <span>established 2022 · ten cents</span>
      </div>

      {/* masthead */}
      <div style={{ textAlign: 'center', padding: '14px 0 6px 0' }}>
        <div style={{
          fontSize: 9.5, letterSpacing: '0.5em', textTransform: 'uppercase',
          color: BS_FADE, marginBottom: 4,
        }}>— published whenever something changes —</div>
        <h1 style={{
          fontFamily: "'DM Serif Display', 'Playfair Display', serif",
          fontSize: 96, lineHeight: 0.95, margin: 0,
          letterSpacing: '-0.025em',
          fontWeight: 400, color: BS_INK,
        }}>The Now Edition</h1>
        <div style={{
          fontFamily: "'DM Serif Display', serif",
          fontSize: 13, letterSpacing: '0.04em', marginTop: 4,
          color: BS_INK, fontStyle: 'italic',
        }}>— a periodic dispatch from alex gaoth, in la jolla —</div>
      </div>

      {/* second folio bar (doubled rule) */}
      <div style={{ borderTop: `2px solid ${BS_INK}`, borderBottom: `1px solid ${BS_INK}`, padding: '6px 0', marginTop: 6, marginBottom: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase' }}>
          <span>{NOW.date}</span>
          <span>weather: clear · {NOW.tz}</span>
          <span>circulation: 1 (you)</span>
        </div>
      </div>

      {/* main grid — hero column + 2 sidebar columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.55fr 1px 1fr 1px 1fr', gap: 20 }}>
        {/* === hero column === */}
        <div>
          <div style={{
            fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase',
            color: BS_FADE, marginBottom: 6,
          }}>lead · primary occupation</div>
          <h2 style={{
            fontFamily: "'DM Serif Display', serif",
            fontSize: 38, lineHeight: 1.05, letterSpacing: '-0.018em',
            margin: '0 0 4px 0', fontWeight: 400,
          }}>Building Signalor: Three Months In, the Brand Analytics Are Starting to Bite</h2>
          <div style={{ fontSize: 11, color: BS_FADE, fontStyle: 'italic', marginBottom: 10 }}>
            from our man at la jolla · day 92 since v0.1
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 12 }}>
            <div style={{
              width: 96, height: 96, flexShrink: 0,
              background: BS_INK, color: BS_PAPER,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: "'DM Serif Display', serif", fontSize: 72,
              lineHeight: 0.85, paddingTop: 6,
            }}>B</div>
            <div style={{ fontSize: 13, lineHeight: 1.6, textAlign: 'justify', hyphens: 'auto' }}>
              <strong>SIGNALOR.APP</strong> entered its third production month this week
              with v0.3.2 shipped on monday — a release of <em>+340 / −120</em> across
              the dashboard. our reporter, who is also the author, the only engineer,
              and the QA, calls it "transparent, holistic, and finally fast enough that
              i don't have to apologize for it." three brand pitches were given on
              tuesday through SDx @ UCSD; two are in followups, one ghosted us before
              the slide deck closed.
            </div>
          </div>

          <BSRule />

          {/* 2-up sub-stories */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            <div>
              <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 4 }}>cont. building</div>
              <h3 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 19, lineHeight: 1.15, margin: '0 0 6px 0' }}>
                SDx @ UCSD Continues; This Site Quietly Redesigned
              </h3>
              <div style={{ fontSize: 12, lineHeight: 1.55, textAlign: 'justify', hyphens: 'auto', color: BS_INK }}>
                also on the bench: the design-engineering club, where four hours
                tuesday went to brand work. and the page you are currently reading,
                which has been quietly redrawn over the last week. <em>continued p.2</em>
              </div>
            </div>
            <div>
              <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 4 }}>opinion · learning desk</div>
              <h3 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 19, lineHeight: 1.15, margin: '0 0 6px 0' }}>
                Rust, Tamil, and the Slow Discipline of Writing Plainly
              </h3>
              <div style={{ fontSize: 12, lineHeight: 1.55, textAlign: 'justify', hyphens: 'auto' }}>
                three open files: <strong>rust</strong> (the borrow checker, finally),
                <strong> தமிழ்</strong> (reading aloud, slowly), and the editorial
                project of using fewer words. all three resist being rushed.
              </div>
            </div>
          </div>

          <BSRule margin="14px 0" />

          {/* week wire */}
          <div>
            <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 6 }}>
              this week, by the wire
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${BS_INK}` }}>
                  <th style={{ textAlign: 'left', padding: '4px 6px 4px 0', fontSize: 9.5, letterSpacing: '0.18em', textTransform: 'uppercase', color: BS_FADE, fontWeight: 500, width: 50 }}>day</th>
                  <th style={{ textAlign: 'left', padding: '4px 0',         fontSize: 9.5, letterSpacing: '0.18em', textTransform: 'uppercase', color: BS_FADE, fontWeight: 500 }}>dispatch</th>
                  <th style={{ textAlign: 'right',padding: '4px 0',         fontSize: 9.5, letterSpacing: '0.18em', textTransform: 'uppercase', color: BS_FADE, fontWeight: 500, width: 90 }}>meta</th>
                </tr>
              </thead>
              <tbody>
                {NOW.thisWeek.map((d, i) => (
                  <tr key={i} style={{ borderBottom: `1px dotted ${BS_RULE}` }}>
                    <td style={{ padding: '5px 6px 5px 0', color: BS_FADE, fontFamily: "'Space Mono', monospace" }}>{d.day}</td>
                    <td style={{ padding: '5px 0', color: BS_INK }}>{d.val}</td>
                    <td style={{ padding: '5px 0', color: BS_FADE, textAlign: 'right', fontSize: 11 }}>{d.tag}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <BSColumnRule />

        {/* === middle column · consuming + writing === */}
        <div>
          <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 6 }}>arts & letters</div>
          <h3 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 24, lineHeight: 1.1, margin: '0 0 10px 0' }}>
            What He Is Reading, Hearing, &amp; Watching
          </h3>
          {NOW.consuming.map((c, i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '54px 1fr', gap: 8, padding: '6px 0', borderTop: i === 0 ? `1px solid ${BS_INK}` : `1px dotted ${BS_RULE}`, alignItems: 'baseline' }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 12, letterSpacing: '0.02em', fontStyle: 'italic', color: BS_INK }}>{c.kind}.</div>
              <div>
                <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>{c.val}</div>
                <div style={{ fontSize: 10.5, color: BS_FADE, fontStyle: 'italic' }}>{c.meta}</div>
              </div>
            </div>
          ))}

          <div style={{ marginTop: 22 }}>
            <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 6 }}>desk · writing room</div>
            <h3 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 22, lineHeight: 1.1, margin: '0 0 8px 0' }}>
              In Drafts
            </h3>
            {NOW.writing.map((w, i) => (
              <div key={i} style={{ padding: '7px 0', borderTop: i === 0 ? `1px solid ${BS_INK}` : `1px dotted ${BS_RULE}`, display: 'flex', gap: 10, alignItems: 'baseline' }}>
                <span style={{
                  fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
                  border: `1px solid ${w.state === 'stuck' ? '#9b2a1e' : BS_INK}`,
                  color: w.state === 'stuck' ? '#9b2a1e' : BS_INK,
                  padding: '1px 6px', whiteSpace: 'nowrap',
                }}>{w.state}</span>
                <span style={{ fontSize: 12, lineHeight: 1.4, color: BS_INK }}>{w.val}</span>
              </div>
            ))}
          </div>
        </div>

        <BSColumnRule />

        {/* === right column · briefs + dateline === */}
        <div>
          <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 6 }}>briefs</div>
          <h3 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 22, lineHeight: 1.1, margin: '0 0 10px 0' }}>
            In Other News
          </h3>
          {NOW.learning.map((l, i) => (
            <div key={i} style={{ padding: '7px 0', borderTop: i === 0 ? `1px solid ${BS_INK}` : `1px dotted ${BS_RULE}` }}>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 14, fontStyle: 'italic' }}>{l.name}</div>
              <div style={{ fontSize: 11.5, color: BS_FADE, lineHeight: 1.4 }}>{l.detail}</div>
            </div>
          ))}

          <BSRule margin="22px 0" />

          {/* dateline / box */}
          <div style={{ border: `2px solid ${BS_INK}`, padding: '12px 14px', background: BS_PAPER }}>
            <div style={{ fontSize: 9, letterSpacing: '0.28em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 6 }}>dateline</div>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 18, lineHeight: 1.15, marginBottom: 6 }}>
              LA JOLLA, CALIF.
            </div>
            <div style={{ fontSize: 11.5, lineHeight: 1.5 }}>
              home for summer. SDx @ UCSD all week. local time tracking PDT;
              expected on campus monday morning.
            </div>
          </div>

          {/* small ad */}
          <div style={{ marginTop: 16, border: `1px solid ${BS_INK}`, padding: '10px 12px', textAlign: 'center' }}>
            <div style={{ fontSize: 9, letterSpacing: '0.28em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 2 }}>house ad</div>
            <div style={{ fontFamily: "'DM Serif Display', serif", fontStyle: 'italic', fontSize: 16, lineHeight: 1.15, margin: '6px 0' }}>
              "the good and the bad."
            </div>
            <a href="#/quotes" style={{ fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase', color: BS_INK }}>
              read /quotes →
            </a>
          </div>
        </div>
      </div>

      {/* ── BACK OF THE PAPER · classifieds ───────────────────── */}
      <div style={{ borderTop: `4px double ${BS_INK}`, marginTop: 28, paddingTop: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
          <div>
            <div style={{ fontSize: 9.5, letterSpacing: '0.32em', textTransform: 'uppercase', color: BS_FADE }}>back page</div>
            <h2 style={{ fontFamily: "'DM Serif Display', serif", fontWeight: 400, fontSize: 30, margin: '2px 0 0 0', letterSpacing: '-0.01em' }}>
              The Classifieds
            </h2>
          </div>
          <div style={{ fontSize: 11, color: BS_FADE, maxWidth: '38ch', textAlign: 'right', lineHeight: 1.45 }}>
            place a one-line ad. choose a column. it goes up next to alex's life
            in print. (kept on your device only.)
          </div>
        </div>

        {/* form */}
        <form onSubmit={submit} style={{
          display: 'grid',
          gridTemplateColumns: 'auto 140px 1fr auto',
          gap: 10, alignItems: 'stretch',
          padding: '12px 0', borderTop: `1px solid ${BS_INK}`, borderBottom: `1px solid ${BS_INK}`,
        }}>
          <select value={category} onChange={(e) => setCategory(e.target.value)} style={{
            background: 'transparent', border: `1px solid ${BS_INK}`,
            padding: '8px 10px', fontFamily: "'Space Mono', monospace",
            fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase',
            color: BS_INK, outline: 'none',
          }}>
            {CLASSIFIED_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <input type="text" placeholder="signed (or anon.)" maxLength={20} value={name} onChange={(e) => setName(e.target.value)} style={{
            background: 'transparent', border: `1px solid ${BS_INK}`,
            padding: '8px 10px', fontFamily: "'Space Mono', monospace", fontSize: 12, color: BS_INK, outline: 'none',
          }} />
          <input type="text" placeholder="one line, ≤ 110 char." maxLength={110} value={draft} onChange={(e) => setDraft(e.target.value)} style={{
            background: 'transparent', border: `1px solid ${BS_INK}`,
            padding: '8px 10px', fontFamily: "'Space Mono', monospace", fontSize: 12, color: BS_INK, outline: 'none',
          }} />
          <button type="submit" style={{
            background: BS_INK, color: BS_PAPER, border: `1px solid ${BS_INK}`,
            fontFamily: "'Space Mono', monospace", fontSize: 11,
            letterSpacing: '0.2em', textTransform: 'uppercase',
            padding: '8px 18px', cursor: 'pointer',
          }}>set type →</button>
        </form>

        {/* ad columns */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', columnGap: 22, marginTop: 14, fontSize: 12 }}>
          {(notes.length ? notes : []).map((n, i) => (
            <div key={i} style={{
              breakInside: 'avoid', padding: '8px 0',
              borderBottom: `1px dotted ${BS_RULE}`,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9, letterSpacing: '0.22em', textTransform: 'uppercase', color: BS_FADE, marginBottom: 3 }}>
                <span>// {n.category || 'rec'}</span>
                <span>{fmtStamp(n._ts || n.ts)}</span>
              </div>
              <div style={{ fontSize: 12.5, lineHeight: 1.45, color: BS_INK }}>
                {n.text}
              </div>
              <div style={{ fontSize: 10.5, color: BS_FADE, fontStyle: 'italic', marginTop: 2 }}>— {n.name}</div>
            </div>
          ))}
        </div>

        {notes.length === 0 && (
          <div style={{ fontSize: 12, color: BS_FADE, fontStyle: 'italic', padding: '12px 0' }}>
            (no advertisers this edition. be the first.)
          </div>
        )}

        {/* footer */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', marginTop: 16,
          borderTop: `1px solid ${BS_INK}`, paddingTop: 8,
          fontSize: 9.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: BS_FADE,
        }}>
          <span>— end edition —</span>
          <span>set in dm serif display &amp; space mono</span>
          <button onClick={clearNotes} style={{
            background: 'none', border: 'none', color: BS_FADE,
            fontFamily: "'Space Mono', monospace", fontSize: 9.5,
            letterSpacing: '0.22em', textTransform: 'uppercase', cursor: 'pointer',
          }}>clear classifieds ✕</button>
        </div>
      </div>
    </div>
  );
}

window.BroadsheetNow = BroadsheetNow;
