// option4-catalog.jsx
// /now as a library catalog — cream checkout cards laid on a desk blotter,
// brass tacks, date-due stamps in red ink. Visitor fills a "PATRON SUGGESTION"
// slip recommending something for Alex to consume; it gets stamped + filed.

const CG_KEY    = 'now_catalog_v1';
const CG_BG     = '#2a3530';                     // dark moss / felt desk
const CG_BG2    = '#1f2724';                     // deeper felt for variety
const CG_CARD   = '#f1ead5';                     // checkout-card cream
const CG_SLIP   = '#e9dfc1';                     // slightly darker slip
const CG_INK    = '#1c1a14';
const CG_FADE   = '#74695a';
const CG_RED    = '#9c2920';
const CG_RULE   = 'rgba(28, 26, 20, 0.18)';
const CG_TACK   = '#b9a16a';

function CGTack({ top = 12, left = 12, color = CG_TACK }) {
  return (
    <div style={{
      position: 'absolute', top, left,
      width: 12, height: 12, borderRadius: 12,
      background: `radial-gradient(circle at 35% 30%, ${color} 0%, #6f5e30 70%, #3a2f12 100%)`,
      boxShadow: '0 1px 2px rgba(0,0,0,0.35), inset 0 1px 1px rgba(255,255,255,0.18)',
      zIndex: 2,
    }} />
  );
}

function CGStamp({ children, rotate = -6, color = CG_RED, scale = 1 }) {
  return (
    <span style={{
      display: 'inline-block',
      transform: `rotate(${rotate}deg) scale(${scale})`,
      border: `2px solid ${color}`,
      color, padding: '3px 9px',
      fontFamily: "'Space Mono', monospace",
      fontSize: 10.5, letterSpacing: '0.22em',
      fontWeight: 700, opacity: 0.85,
      textTransform: 'uppercase',
    }}>{children}</span>
  );
}

function CGCard({ children, rotate = 0, style }) {
  return (
    <div style={{
      position: 'relative',
      background: CG_CARD,
      color: CG_INK,
      transform: `rotate(${rotate}deg)`,
      boxShadow: '0 6px 14px rgba(0,0,0,0.25), 0 1px 2px rgba(0,0,0,0.18)',
      backgroundImage: `
        repeating-linear-gradient(to bottom, transparent 0 26px, rgba(70, 100, 140, 0.10) 26px 27px)
      `,
      backgroundPosition: '0 36px',
      ...style,
    }}>{children}</div>
  );
}

function CGCardHeader({ label, callno }) {
  return (
    <div style={{
      padding: '8px 14px 6px 14px',
      borderBottom: `2px solid ${CG_INK}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
      background: 'rgba(0,0,0,0.04)',
    }}>
      <span style={{ fontSize: 9.5, letterSpacing: '0.28em', textTransform: 'uppercase', color: CG_FADE, fontFamily: "'Space Mono', monospace" }}>
        the now page · checkout record
      </span>
      <span style={{ fontSize: 10, letterSpacing: '0.2em', color: CG_INK, fontFamily: "'Space Mono', monospace" }}>
        call no. {callno}
      </span>
    </div>
  );
}

function CGStampGrid({ stamps, cols = 3 }) {
  // grid of past "date due" stamps to show update history
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: `repeat(${cols}, 1fr)`,
      gap: 6,
      borderTop: `1px solid ${CG_RULE}`,
      padding: '10px 14px',
      background: 'rgba(0,0,0,0.025)',
    }}>
      {stamps.map((s, i) => (
        <div key={i} style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: 9.5,
          letterSpacing: '0.18em',
          color: CG_RED, textTransform: 'uppercase',
          border: `1px solid ${CG_RED}`,
          padding: '2px 0', textAlign: 'center',
          opacity: i === stamps.length - 1 ? 1 : 0.55,
          transform: `rotate(${(i % 3 - 1) * 1.5}deg)`,
        }}>{s}</div>
      ))}
    </div>
  );
}

function CGSectionCard({ title, subtitle, callno, items, renderItem, stamps, rotate, gridArea }) {
  return (
    <div style={{ gridArea, position: 'relative' }}>
      <CGCard rotate={rotate}>
        <CGTack top={-4} left={20} />
        <CGTack top={-4} left={'calc(100% - 32px)'} />
        <CGCardHeader callno={callno} />
        <div style={{ padding: '14px 16px 6px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
            <h3 style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontWeight: 600, fontSize: 24, margin: 0,
              letterSpacing: '-0.015em', textTransform: 'lowercase',
            }}>{title}</h3>
            <span style={{ fontSize: 10, letterSpacing: '0.18em', color: CG_FADE, textTransform: 'uppercase' }}>
              {items.length} record{items.length === 1 ? '' : 's'}
            </span>
          </div>
          <div style={{ fontSize: 10.5, color: CG_FADE, fontStyle: 'italic', marginBottom: 10 }}>{subtitle}</div>
          <div>
            {items.map((it, i) => (
              <div key={i} style={{
                fontFamily: "'Space Mono', monospace",
                fontSize: 12.5, lineHeight: '26px', height: 26,
                color: CG_INK, display: 'flex', alignItems: 'center',
                borderBottom: `1px solid ${CG_RULE}`,
              }}>{renderItem(it, i)}</div>
            ))}
          </div>
        </div>
        <CGStampGrid stamps={stamps} />
      </CGCard>
    </div>
  );
}

function CatalogNow() {
  const [draft, setDraft]   = React.useState('');
  const [name, setName]     = React.useState('');
  const [kind, setKind]     = React.useState('read');
  const [slips, addSlip, clearSlips] = useNotes(CG_KEY);

  React.useEffect(() => {
    if (slips.length === 0) {
      const now = Date.now();
      addSlip({ name: 'i. yelchin', kind: 'watch', text: 'koyaanisqatsi (1982). watch in one sitting, ideally late.', _ts: now - 3600e3 * 31 });
      addSlip({ name: 'a. mehta',   kind: 'read',  text: 'the master and his emissary — iain mcgilchrist. it answers some of jung.', _ts: now - 3600e3 * 9 });
      addSlip({ name: 'anon.',      kind: 'sound', text: 'caroline polachek — desire, i want to turn into you. (full album).', _ts: now - 3600e3 * 2 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    addSlip({ name: (name.trim() || 'anon.').slice(0, 24), kind, text: trimmed.slice(0, 160) });
    setDraft(''); setName('');
  };

  // stamp history pulled from a fixed list — older dates with the last being today
  const STAMPS = (extra = []) => ['10 apr 26', '24 apr 26', '02 may 26', '09 may 26', '14 may 26', '16 may 26', ...extra];

  return (
    <div style={{
      background: `
        radial-gradient(circle at 30% 20%, ${CG_BG} 0%, ${CG_BG2} 80%)
      `,
      minHeight: '100%',
      padding: '36px 40px 48px 40px',
      color: CG_CARD,
      fontFamily: "'Space Mono', monospace",
      backgroundImage: `
        radial-gradient(rgba(255, 240, 200, 0.018) 1px, transparent 1px),
        radial-gradient(rgba(255, 240, 200, 0.012) 1px, transparent 1px),
        radial-gradient(circle at 30% 20%, ${CG_BG} 0%, ${CG_BG2} 80%)
      `,
      backgroundSize: '4px 4px, 9px 9px, 100% 100%',
    }}>
      {/* header — printed on the felt */}
      <header style={{
        textAlign: 'center', padding: '6px 0 20px 0',
        borderBottom: `1px solid rgba(255, 240, 200, 0.18)`,
        marginBottom: 28,
      }}>
        <div style={{ fontSize: 10, letterSpacing: '0.4em', textTransform: 'uppercase', color: 'rgba(255, 240, 200, 0.55)' }}>
          alex gaoth · patron catalog
        </div>
        <h1 style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontWeight: 600, fontSize: 76, margin: '4px 0 0 0',
          letterSpacing: '-0.04em', lineHeight: 0.95,
          color: CG_CARD, textTransform: 'lowercase',
        }}>the now page<span style={{ color: CG_TACK }}>.</span></h1>
        <div style={{ marginTop: 6, fontSize: 11.5, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(255, 240, 200, 0.55)' }}>
          {NOW.date} &nbsp;·&nbsp; {NOW.edition} &nbsp;·&nbsp; {NOW.location}
        </div>
      </header>

      {/* 4-up card grid */}
      <div style={{
        display: 'grid',
        gridTemplateAreas: `
          "build read"
          "learn write"
        `,
        gridTemplateColumns: '1fr 1fr',
        gap: '30px 36px',
        padding: '0 6px 20px 6px',
      }}>
        <CGSectionCard
          gridArea="build" rotate={-0.6}
          title="building" subtitle="// projects with the lamp on" callno="N.001"
          items={NOW.building}
          stamps={STAMPS()}
          renderItem={(b) => (
            <span style={{ display: 'flex', alignItems: 'baseline', gap: 10, width: '100%' }}>
              <span style={{
                fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
                color: b.tag === 'live' ? CG_RED : CG_INK,
                border: '1px solid currentColor', padding: '1px 5px',
              }}>{b.tag}</span>
              <strong style={{ fontWeight: 500 }}>{b.name}</strong>
              <span style={{ color: CG_FADE, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>— {b.detail}</span>
            </span>
          )}
        />
        <CGSectionCard
          gridArea="read" rotate={0.4}
          title="consuming" subtitle="// inputs · sound, read, watch, play" callno="N.002"
          items={NOW.consuming}
          stamps={STAMPS()}
          renderItem={(c) => (
            <span style={{ display: 'flex', alignItems: 'baseline', gap: 10, width: '100%' }}>
              <span style={{ fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: CG_FADE, minWidth: 56 }}>{c.kind}</span>
              <span style={{ color: CG_INK, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{c.val}</span>
              <span style={{ fontSize: 10, color: CG_FADE, fontStyle: 'italic', whiteSpace: 'nowrap' }}>{c.meta}</span>
            </span>
          )}
        />
        <CGSectionCard
          gridArea="learn" rotate={0.3}
          title="learning" subtitle="// cognitive load · slow burns" callno="N.003"
          items={NOW.learning}
          stamps={STAMPS()}
          renderItem={(l) => (
            <span style={{ display: 'flex', alignItems: 'baseline', gap: 10, width: '100%' }}>
              <strong style={{ fontWeight: 500, minWidth: 130 }}>{l.name}</strong>
              <span style={{ color: CG_FADE, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{l.detail}</span>
            </span>
          )}
        />
        <CGSectionCard
          gridArea="write" rotate={-0.4}
          title="writing" subtitle="// drafts in flight" callno="N.004"
          items={NOW.writing}
          stamps={STAMPS()}
          renderItem={(w) => (
            <span style={{ display: 'flex', alignItems: 'baseline', gap: 10, width: '100%' }}>
              <span style={{
                fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase',
                color: w.state === 'stuck' ? CG_RED : CG_INK,
                border: '1px solid currentColor', padding: '1px 5px',
                minWidth: 50, textAlign: 'center',
              }}>{w.state}</span>
              <span style={{ color: CG_INK, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{w.val}</span>
            </span>
          )}
        />
      </div>

      {/* this-week strip — long card */}
      <div style={{ position: 'relative', margin: '6px 6px 28px 6px' }}>
        <CGCard rotate={0.2} style={{ backgroundImage: `
          repeating-linear-gradient(to right, transparent 0 calc(100%/5 - 1px), ${CG_RULE} calc(100%/5 - 1px) calc(100%/5)),
          repeating-linear-gradient(to bottom, transparent 0 26px, rgba(70, 100, 140, 0.08) 26px 27px)
        `, backgroundPosition: '0 0, 0 30px' }}>
          <CGTack top={-4} left={28} />
          <CGTack top={-4} left={'calc(50% - 6px)'} />
          <CGTack top={-4} left={'calc(100% - 40px)'} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '8px 16px', borderBottom: `2px solid ${CG_INK}`, background: 'rgba(0,0,0,0.04)' }}>
            <span style={{ fontSize: 9.5, letterSpacing: '0.28em', textTransform: 'uppercase', color: CG_FADE }}>
              the now page · weekly checkouts · w20
            </span>
            <CGStamp rotate={-3}>week active</CGStamp>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', padding: 0 }}>
            {NOW.thisWeek.map((d, i) => (
              <div key={i} style={{
                padding: '12px 14px',
                borderRight: i < 4 ? `1px dashed ${CG_RULE}` : 'none',
                minHeight: 96, display: 'flex', flexDirection: 'column', gap: 6,
              }}>
                <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: CG_FADE }}>{d.day}</div>
                <div style={{ fontSize: 13, color: CG_INK, lineHeight: 1.35 }}>{d.val}</div>
                <div style={{ fontSize: 10, color: CG_FADE, marginTop: 'auto' }}>{d.tag}</div>
              </div>
            ))}
          </div>
        </CGCard>
      </div>

      {/* patron suggestion slip + filed slips */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.1fr 1.3fr',
        gap: 28,
        padding: '0 6px',
      }}>
        {/* form slip */}
        <div style={{ position: 'relative' }}>
          <CGCard rotate={-1.2} style={{
            background: CG_SLIP,
            backgroundImage: `
              repeating-linear-gradient(to bottom, transparent 0 24px, rgba(155, 42, 30, 0.10) 24px 25px)
            `,
            backgroundPosition: '0 56px',
          }}>
            <CGTack top={-4} left={30} />
            <div style={{ padding: '14px 18px 6px 18px', borderBottom: `2px dashed ${CG_INK}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div>
                  <div style={{ fontSize: 9, letterSpacing: '0.32em', textTransform: 'uppercase', color: CG_FADE }}>form NP-05</div>
                  <h3 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 22, margin: 0, letterSpacing: '-0.015em', color: CG_INK, textTransform: 'lowercase', fontWeight: 600 }}>
                    patron suggestion slip
                  </h3>
                </div>
                <CGStamp rotate={6}>pls. fill in</CGStamp>
              </div>
              <div style={{ fontSize: 11, color: CG_FADE, marginTop: 8, lineHeight: 1.5 }}>
                recommend something for alex to read / hear / watch / play.
                stamped + filed on submit. kept locally on your device.
              </div>
            </div>

            <form onSubmit={submit} style={{ padding: '14px 18px 18px 18px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr', gap: 10, fontFamily: "'Space Mono', monospace", fontSize: 12, color: CG_INK, alignItems: 'center' }}>
                <span style={{ fontSize: 9.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: CG_FADE }}>patron:</span>
                <input type="text" placeholder="your name (or anon.)" maxLength={24} value={name} onChange={(e) => setName(e.target.value)} style={{
                  background: 'transparent', border: 'none', borderBottom: `1px solid ${CG_INK}`,
                  padding: '6px 4px', fontFamily: "'Space Mono', monospace", fontSize: 12.5, color: CG_INK, outline: 'none',
                }} />

                <span style={{ fontSize: 9.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: CG_FADE }}>kind:</span>
                <div style={{ display: 'flex', gap: 14, padding: '4px 0' }}>
                  {['read', 'sound', 'watch', 'play'].map(k => (
                    <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, cursor: 'pointer' }}>
                      <span style={{
                        display: 'inline-block', width: 13, height: 13,
                        border: `2px solid ${CG_INK}`,
                        background: kind === k ? CG_INK : 'transparent',
                        position: 'relative',
                      }}>
                        {kind === k && <span style={{ position: 'absolute', inset: 1, color: CG_CARD, fontSize: 10, lineHeight: '9px', textAlign: 'center' }}>✕</span>}
                      </span>
                      <input type="radio" name="kind" value={k} checked={kind === k} onChange={() => setKind(k)} style={{ display: 'none' }} />
                      {k}
                    </label>
                  ))}
                </div>

                <span style={{ fontSize: 9.5, letterSpacing: '0.22em', textTransform: 'uppercase', color: CG_FADE, alignSelf: 'flex-start', paddingTop: 6 }}>rec.:</span>
                <textarea
                  placeholder="one recommendation — title + one-line why" maxLength={160} rows={3}
                  value={draft} onChange={(e) => setDraft(e.target.value)}
                  style={{
                    background: 'transparent', border: 'none', borderBottom: `1px solid ${CG_INK}`,
                    padding: '6px 4px', fontFamily: "'Space Mono', monospace",
                    fontSize: 12.5, color: CG_INK, outline: 'none', resize: 'none', lineHeight: 1.5,
                  }}
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 }}>
                <span style={{ fontSize: 10, letterSpacing: '0.16em', color: CG_FADE, textTransform: 'uppercase' }}>
                  // ≤ 160 char. one rec per slip.
                </span>
                <button type="submit" style={{
                  background: CG_INK, color: CG_CARD, border: `1px solid ${CG_INK}`,
                  fontFamily: "'Space Mono', monospace", fontSize: 11.5,
                  letterSpacing: '0.2em', textTransform: 'uppercase',
                  padding: '9px 22px', cursor: 'pointer',
                }}>stamp &amp; file →</button>
              </div>
            </form>
          </CGCard>
        </div>

        {/* filed slips stack */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '0 0 10px 0' }}>
            <div>
              <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: 'rgba(255, 240, 200, 0.55)' }}>
                // filed slips
              </div>
              <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 22, color: CG_CARD, letterSpacing: '-0.01em', textTransform: 'lowercase' }}>
                what visitors have recommended
              </div>
            </div>
            <button onClick={clearSlips} style={{
              background: 'none', border: '1px solid rgba(255, 240, 200, 0.3)', color: 'rgba(255, 240, 200, 0.6)',
              fontFamily: "'Space Mono', monospace", fontSize: 9.5,
              letterSpacing: '0.18em', textTransform: 'uppercase',
              padding: '4px 10px', cursor: 'pointer',
            }}>clear ✕</button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxHeight: 460, overflowY: 'auto', paddingRight: 6 }}>
            {slips.length === 0 ? (
              <div style={{ color: 'rgba(255, 240, 200, 0.55)', fontStyle: 'italic', fontSize: 12.5, padding: '20px 0' }}>
                (no slips filed yet — be the first patron)
              </div>
            ) : slips.map((s, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <CGCard rotate={(i % 2 === 0 ? -0.7 : 0.6)} style={{ background: CG_SLIP, backgroundImage: 'none' }}>
                  <CGTack top={-4} left={'calc(50% - 6px)'} />
                  <div style={{ padding: '10px 14px', display: 'grid', gridTemplateColumns: '1fr auto', gap: 12, alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ display: 'flex', gap: 10, alignItems: 'baseline', marginBottom: 4 }}>
                        <span style={{
                          fontSize: 9, letterSpacing: '0.22em', textTransform: 'uppercase',
                          color: CG_RED, border: `1px solid ${CG_RED}`, padding: '1px 6px',
                        }}>{s.kind || 'rec'}</span>
                        <span style={{ fontSize: 10, color: CG_FADE, letterSpacing: '0.1em' }}>
                          patron: {s.name}
                        </span>
                      </div>
                      <div style={{ fontSize: 12.5, color: CG_INK, lineHeight: 1.45 }}>{s.text}</div>
                    </div>
                    <div style={{
                      transform: 'rotate(-8deg)',
                      border: `1.5px solid ${CG_RED}`, color: CG_RED,
                      fontFamily: "'Space Mono', monospace", fontSize: 9.5,
                      letterSpacing: '0.18em', textTransform: 'uppercase',
                      padding: '3px 7px', whiteSpace: 'nowrap',
                      lineHeight: 1.2, textAlign: 'center',
                    }}>
                      stamped<br />{fmtStamp(s._ts || s.ts).split(' · ')[0]}
                    </div>
                  </div>
                </CGCard>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* footer */}
      <footer style={{
        marginTop: 36, paddingTop: 14,
        borderTop: `1px solid rgba(255, 240, 200, 0.18)`,
        display: 'flex', justifyContent: 'space-between',
        fontSize: 10, letterSpacing: '0.22em',
        textTransform: 'uppercase', color: 'rgba(255, 240, 200, 0.55)',
      }}>
        <span>// catalog est. 2022 · derek sivers' /now</span>
        <span>{NOW.tz} · last sync just now</span>
      </footer>
    </div>
  );
}

window.CatalogNow = CatalogNow;
